import Filters from "../components/Filters";
import { ProductContainer, PaginationsContainer } from "../components";
import { customFetch } from "../utils";
export const loader = async () => {
  const request = await customFetch("/products");
  const products = request.data.data;
  const meta = request.data.meta;
  return { products, meta };
};
function Products() {
  return (
    <div>
      {/* Filters */}
      <Filters />
      {/* ProductsContainer */}
      <ProductContainer />
      {/* PaginationsContainer */}
      <PaginationsContainer />
    </div>
  );
}

export default Products;
